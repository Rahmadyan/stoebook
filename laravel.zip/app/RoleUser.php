<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoleUser extends Model
{
     protected $table = 'role_user';
 
    /**
     * sementara ini aja dulu,
     * karena Model ini akan berguna jika kita membuat multi user di aplikasi kita nantinya.
     */
}
