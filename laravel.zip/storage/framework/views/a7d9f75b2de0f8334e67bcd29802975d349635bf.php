  <div>
  <img class="img-circle" width="40px" height="40px" src="<?php echo e(asset('img')); ?>/<?php echo e($comment->user->avatar); ?>" >
  <lead>by <?php echo e($comment->user->firstname); ?></lead>  
  <h4><?php echo e($comment->body); ?></h4>  
                    
                    
                    
                    
                    <div class="action">
                      
                    <?php if(auth()->user()->id == $comment->user_id): ?> 
                     <a class="btn btn-box-tool fa fa-edit pull-right" data-toggle="modal" href='#<?php echo e($comment->id); ?>'></a>

                      <div class="modal fade" id="<?php echo e($comment->id); ?>">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title">Modal title</h4>
                            </div>
                            <div class="modal-body">
                              
                              <div class="comment-form">
                                <form action="<?php echo e(route('comment.update',$comment->id)); ?>" method="POST" role="form">
                                  <?php echo e(csrf_field()); ?>

                                  <?php echo e(method_field('put')); ?>

                                  <legend>Edit Comment</legend>
                                
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="body" id="" placeholder="Input field" value="<?php echo e($comment->body); ?>">
                                  </div>
                                
                                  <button type="submit" class="btn btn-primary">comment</button>
                                </form>
                              </div>

                            </div>
                            
                          </div>
                        </div>
                      </div>
                       
                      <form action="<?php echo e(route('comment.destroy',$comment->id)); ?>" method="POST" class="inline-it">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" class="btn btn-box-tool fa fa-trash pull-right" value="Delete"></button>
                      </form> 
                      <?php endif; ?>

                        <button class="btn btn-box-tool fa fa-mail-reply pull-right" onclick="toggleReply('<?php echo e($comment->id); ?>')"></button>

                        

                    </div>
                  </div>
                    