<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <li>PHP</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <center>
        <h1><?php echo e($title); ?></h1>
        <p><?php echo e($content); ?></p>
        <p>Username : <?php echo e($profile->user->name); ?></p>
        <p>Email : <?php echo e($profile->user->email); ?></p>
    </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>