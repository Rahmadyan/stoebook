
	<div class="list-group">
		<?php $__empty_1 = true; $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<a class="list-group-item" href="<?php echo e(url('thread', $key->id)); ?>

		">
			<div class="user-block">
				
				<img class="img-circle" src="<?php echo e(asset('img')); ?>/<?php echo e($key->user->avatar); ?>" >
				<span class="username">
                    <h4 class="list-group-item-heading"><?php echo e($key->subject); ?> <i class="fa fa-comments-o pull-right"> <?php echo e($key->comments()->count()); ?></i></h4>
                </span>
                <span class="description">
                	<i class="fa fa-users pull-left">
	                By : <?php echo e($key->user->name); ?>, <?php echo e($key->created_at); ?></i>
                </span>
				<br>
			</div>
				<p>
					<?php echo e(str_limit(strip_tags($key->thread),250)); ?>


				</p>
		</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		
		<h5>No Threads</h5>
		<?php endif; ?>

	</div>


	

		
		
	
	
