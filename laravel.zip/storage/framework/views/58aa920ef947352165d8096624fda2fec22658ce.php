<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <li>PHP</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <center>
    	<h1><?php echo e($title); ?></h1>
    	<p><?php echo e($content); ?></p>
    	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<h3>Nama : <?php echo e($user->name); ?></h3>
		</tr>
        <table>
    		<thead>
    			<tr>
    				<th>Kendaraan</th>
    				<th>Jenis Kendaraan</th>
    				<th>Buatan</th>
    			</tr>
    		</thead>
    		<tbody>
				<?php $__currentLoopData = $user->kendaraans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kendaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
	    				<td><?php echo e($kendaraan->nama_kendaraan); ?></td>
	    				<td><?php echo e($kendaraan->nama_kendaraan); ?></td>
	    				<td><?php echo e($kendaraan->buatan); ?></td>
	    			</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</tbody>
    	</table>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>