<div style="margin-left: 40px">
  <img class="img-circle" width="40px" height="40px" src="<?php echo e(asset('img')); ?>/<?php echo e($reply->user->avatar); ?>" >
  <lead>by <?php echo e($reply->user->firstname); ?></lead>
  <p><?php echo e($reply->body); ?></p>
                    
                      <div class="action">
                        
                        <?php if(auth()->user()->id == $reply->user_id): ?>
                       <a class="btn btn-box-tool fa fa-edit pull-right" data-toggle="modal" href='#<?php echo e($reply->id); ?>'></a>
                        <div class="modal fade" id="<?php echo e($reply->id); ?>">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Modal title</h4>
                              </div>
                              <div class="modal-body">
                                
                                <div class="comment-form">
                                  <form action="<?php echo e(route('comment.update',$reply->id)); ?>" method="POST" role="form">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('put')); ?>

                                    <legend>Edit Comment</legend>
                                  
                                    <div class="form-group">
                                      <input type="text" class="form-control" name="body" id="" placeholder="Input field" value="<?php echo e($reply->body); ?>">
                                    </div>
                                  
                                    <button type="submit" class="btn btn-primary">Reply</button>
                                  </form>
                                </div>

                              </div>
                              
                            </div>
                          </div>
                        </div>

                        <form action="<?php echo e(route('comment.destroy',$reply->id)); ?>" method="POST" class="inline-it">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('DELETE')); ?>

                          <button type="submit" class="btn btn-box-tool fa fa-trash pull-right" value="Delete"></button>
                        </form> 

                        <?php endif; ?>
                      </div>

                    </div>