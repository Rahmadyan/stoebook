<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<h1>Selamat datang di blog</h1>
	<h2><?php echo e($blog); ?></h2>
	<h3><?php echo e($user); ?></h3>

	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($key); ?></li>
		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</body>
</html>