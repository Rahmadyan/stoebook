<a href="<?php echo e(route('opennotif',$notification->data['thread']['id'])); ?>">
	
	<?php echo e($notification->data['user']['name']); ?> commented on <strong> <?php echo e($notification->data['thread']['subject']); ?></strong>

</a>

